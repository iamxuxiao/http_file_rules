#include <stdio.h>

void hello_func(void);
